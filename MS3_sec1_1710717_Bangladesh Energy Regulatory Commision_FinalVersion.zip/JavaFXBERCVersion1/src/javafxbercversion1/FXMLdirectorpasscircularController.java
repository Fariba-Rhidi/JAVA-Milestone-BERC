/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fariba Rhidi
 */
public class FXMLdirectorpasscircularController implements Initializable {

    @FXML
    private Label directorpasscircular;
    @FXML
    private TextField directorCircular;
    @FXML
    private TextField directorwritecommentPassCircular;
    @FXML
    private Button directorsumbitCircular;
    @FXML
    private Button directorBackSubmit;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void directorSeeCircular(ActionEvent event) {
    }

    @FXML
    private void directorcommentCircular(ActionEvent event) {
    }

    @FXML
    private void Directorsubmitcircular(ActionEvent event) {
    }

    @FXML
    private void DirectorSubmitback(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLdirectorlogin.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }
    
}
