/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fariba Rhidi
 */
public class FXMLconsumerlawController implements Initializable {

    @FXML
    private Label consumerseelaw;
    @FXML
    private Button consumerchecklaws;
    @FXML
    private Button consumercheckregulation;
    @FXML
    private Button consumerpolicy;
    @FXML
    private Button consumercheckrules;
    @FXML
    private Button consumerdrafts;
    @FXML
    private Button consumerLawback;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void consumerLawCheck(ActionEvent event) {
    }

    @FXML
    private void consumerRegulation(ActionEvent event) {
    }

    @FXML
    private void consumercheckPolicy(ActionEvent event) {
    }

    @FXML
    private void consumerRuleCheck(ActionEvent event) {
    }

    @FXML
    private void consumerCheckDreafts(ActionEvent event) {
    }

    @FXML
    private void consumerLawGoBack(ActionEvent event) throws IOException {
         Parent p = FXMLLoader.load(getClass().getResource("FXMLconsumerlogin.fxml"));
            Scene s = new Scene(p);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(s);
            window.show();
    }
    
}
