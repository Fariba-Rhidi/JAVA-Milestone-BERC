/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fariba Rhidi
 */
public class FXMLchairmancreateannouncementController implements Initializable {

    @FXML
    private Button chairmancrtanuncement;
    @FXML
    private TextField announcementbychairman;
    @FXML
    private Button chairmanannouncementpost;
    @FXML
    private Button chairmanannouncementback;
    @FXML
    private MenuButton chairmanancmntprivacy;
    @FXML
    private MenuItem chairmanancmtpdirector;
    @FXML
    private MenuItem chairmanancmntemp;
    @FXML
    private MenuItem chairmanprieveryone;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void anumcementforchairman(ActionEvent event) {
    }

    @FXML
    private void announcementchairman(ActionEvent event) {
    }

    @FXML
    private void postannouncementchairman(ActionEvent event) {
    }


    @FXML
    private void backchairmanannouncement(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLchairmanlogin.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }

    @FXML
    private void chairmanPriforDirector(ActionEvent event) {
    }

    @FXML
    private void chairmanAncPrivacymember(ActionEvent event) {
    }

    @FXML
    private void chairmanEveryonePrivacy(ActionEvent event) {
    }

    @FXML
    private void chairmanPrivacyAnuntment(ActionEvent event) {
    }
    
}
