/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fariba Rhidi
 */
public class FXMLchairmanseeGasController implements Initializable {

    @FXML
    private Button gasgoback;
    @FXML
    private TableView<?> chairmanGastable;
    @FXML
    private TableColumn<?, ?> chaiemangastablename;
    @FXML
    private TableColumn<?, ?> colum1;
    @FXML
    private TableColumn<?, ?> namecol2;
    @FXML
    private TableColumn<?, ?> namecol3;
    @FXML
    private TableColumn<?, ?> namecol4;
    @FXML
    private TableColumn<?, ?> chairmantableyear;
    @FXML
    private TableColumn<?, ?> columyear1;
    @FXML
    private TableColumn<?, ?> yearcol2;
    @FXML
    private TableColumn<?, ?> yearcol3;
    @FXML
    private TableColumn<?, ?> yearcol4;
    @FXML
    private TableColumn<?, ?> gastablelocation;
    @FXML
    private TableColumn<?, ?> locationcol1;
    @FXML
    private TableColumn<?, ?> locationcol2;
    @FXML
    private TableColumn<?, ?> locationcol3;
    @FXML
    private TableColumn<?, ?> locationcol4;
    @FXML
    private TableColumn<?, ?> gastablereserves;
    @FXML
    private TableColumn<?, ?> totalcol1;
    @FXML
    private TableColumn<?, ?> reservecol2;
    @FXML
    private TableColumn<?, ?> reservecol3;
    @FXML
    private TableColumn<?, ?> reservecol4;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void gobackGas(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLchairmanlogin.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }
    
}
