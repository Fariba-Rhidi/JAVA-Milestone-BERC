/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fariba Rhidi
 */
public class FXMLchairmancreatepollController implements Initializable {

    @FXML
    private Label chairmancanseeparticipant;
    @FXML
    private Button chairmanpollback;
    @FXML
    private VBox chairmanparilist;
    @FXML
    private TextField participantmem1;
    @FXML
    private TextField participantmem2;
    @FXML
    private TextField participantmem3;
    @FXML
    private TextField participant4mem;
    @FXML
    private MenuButton resultofvotemenu;
    @FXML
    private MenuItem votewinner1;
    @FXML
    private MenuItem votewinner2;
    @FXML
    private CheckBox votemem1;
    @FXML
    private CheckBox votemem2;
    @FXML
    private CheckBox votemem3;
    @FXML
    private CheckBox votemem4;
    @FXML
    private Button votedone;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    @FXML
    private void chairmanbackpoll(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLchairmanlogin.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }

    @FXML
    private void member1parti(ActionEvent event) {
    }

    @FXML
    private void member2parti(ActionEvent event) {
    }

    @FXML
    private void member3parti(ActionEvent event) {
    }

    @FXML
    private void mem4parti(ActionEvent event) {
    }

    @FXML
    private void votefirstwinner(ActionEvent event) {
    }

    @FXML
    private void winner2forvote(ActionEvent event) {
    }

    @FXML
    private void MenuforVoteresult(ActionEvent event) {
    }

    @FXML
    private void voteforMem1(ActionEvent event) {
    }

    @FXML
    private void voteForMem2(ActionEvent event) {
    }

    @FXML
    private void VoteforMem3(ActionEvent event) {
    }

    @FXML
    private void voteforMem4(ActionEvent event) {
    }

    @FXML
    private void Donevote(ActionEvent event) {
    }
    
}
