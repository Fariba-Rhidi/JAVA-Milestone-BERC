/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fariba Rhidi
 */
public class FXMLchairmanschedulformeetingController implements Initializable {

    @FXML
    private Label chairmanmeeting;
    @FXML
    private TextField timeformeeting;
    @FXML
    private TextField chairmanmeetingdate;
    @FXML
    private MenuButton chairmanmeetingprivacy;
    @FXML
    private Button chairmanmeetingdone;
    @FXML
    private Button chairmanbackmeeting;
    @FXML
    private MenuItem chairmanprivacydirector;
    @FXML
    private MenuItem chairmanprivacyemployee;
    @FXML
    private MenuItem chairmanprivacyothers;
    @FXML
    private TextField chairmanmeetingtopic;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void chairmantimeformeeting(ActionEvent event) {
    }

    @FXML
    private void dateformeetingchairman(ActionEvent event) {
    }

    @FXML
    private void chairmanprivacymeeting(ActionEvent event) {
    }

    @FXML
    private void chairmandonemeeting(ActionEvent event) {
    }

    @FXML
    private void chairmanmeetingback(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLchairmanlogin.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }

    @FXML
    private void chairmanmenuDirector(ActionEvent event) {
    }

    @FXML
    private void chairmanmenuEmployee(ActionEvent event) {
    }

    @FXML
    private void chairmanmenuOthers(ActionEvent event) {
    }

    @FXML
    private void chairmanSetmettingTopic(ActionEvent event) {
    }
    
}
