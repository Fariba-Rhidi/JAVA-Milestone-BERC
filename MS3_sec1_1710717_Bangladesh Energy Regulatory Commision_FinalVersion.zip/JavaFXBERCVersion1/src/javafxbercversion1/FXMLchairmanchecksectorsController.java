/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fariba Rhidi
 */
public class FXMLchairmanchecksectorsController implements Initializable {

    @FXML
    private HBox chairmansectornbox;
    @FXML
    private Button chairmansectorGassee;
    @FXML
    private Button chairmansectorPowersee1;
    @FXML
    private Button chairmansectorPetrosee11;
    @FXML
    private Button chairmansectorseegoback;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void chairmanGassectorinfo(ActionEvent event) throws IOException {
         Parent p = FXMLLoader.load(getClass().getResource("FXMLchairmanseeGas.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }

    @FXML
    private void chairmanPowersectorinfo(ActionEvent event) {
    }

    @FXML
    private void chairmanPetrosectorinfo(ActionEvent event) {
    }

    @FXML
    private void chairmanGObackSector(ActionEvent event) throws IOException {
         Parent p = FXMLLoader.load(getClass().getResource("FXMLchairmanlogin.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }
    
}
