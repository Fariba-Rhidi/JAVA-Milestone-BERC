/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbercversion1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 *
 * @author Fariba Rhidi
 */
public class FXMLDocumentController implements Initializable {
    ToggleGroup tg;
    
    private Label label;
    @FXML
    private Label welcome;
    @FXML
    private Label Berc;
    @FXML
    private Label email;
    @FXML
    private Label password;
    @FXML
    private TextField email1;
    @FXML
    private TextField passwrd1;
    @FXML
    private Button login1;
    @FXML
    private Button sign;
    @FXML
    private RadioButton forchairman;
    @FXML
    private RadioButton fordirector;
    @FXML
    private RadioButton formember;
    @FXML
    private RadioButton forfinance;
    @FXML
    private RadioButton forconsumer;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        tg = new ToggleGroup();
        forchairman.setToggleGroup(tg);
        fordirector.setToggleGroup(tg);
        formember.setToggleGroup(tg);
        forfinance.setToggleGroup(tg);
        forconsumer.setToggleGroup(tg);
        forchairman.setSelected(true);
    }    
//CHAIRMAN//
    @FXML
    private void login(ActionEvent event) throws IOException {
       if(forchairman.isSelected())
        {
            Parent p = FXMLLoader.load(getClass().getResource("FXMLchairmanlogin.fxml"));
            Scene s = new Scene(p);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(s);
            window.show();
        }
       if(fordirector.isSelected())
        {
            Parent p = FXMLLoader.load(getClass().getResource("FXMLdirectorlogin.fxml"));
            Scene s = new Scene(p);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(s);
            window.show();
        }
       if(formember.isSelected())
        {
            Parent p = FXMLLoader.load(getClass().getResource("FXMLmemberlogin.fxml"));
            Scene s = new Scene(p);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(s);
            window.show();
        }
         if(forfinance.isSelected())
        {
            Parent p = FXMLLoader.load(getClass().getResource("FXMLfinancelogin.fxml"));
            Scene s = new Scene(p);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(s);
            window.show();
        }
          if(forconsumer.isSelected())
        {
            Parent p = FXMLLoader.load(getClass().getResource("FXMLconsumerlogin.fxml"));
            Scene s = new Scene(p);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(s);
            window.show();
        }
         
    }
    

    @FXML
    private void signup(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(getClass().getResource("FXMLsignup.fxml"));
        Scene s = new Scene(p);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(s);
        window.show();
    }

    @FXML
    private void forConsumer(ActionEvent event) {
    }


    
}
